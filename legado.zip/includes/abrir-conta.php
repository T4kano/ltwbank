<div class="bg-include" style="background-image:url('images/bg-banner.jpg')">
	<div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-6 baixar-conta">
				<h6>APLICATIVO</h6>
				<h2>Baixe o App do <span class="color-green">LTW Bank</span> e abra sua conta rapidamente</h2>
				<p>Mais praticidade e segurança em sua conta digital.</p>
				<!--<a href="abrir-conta" class="suave-up btn botao-conta-include">ABRA SUA CONTA</a>-->
				<a href="contato" class="suave-up btn botao-conta-include">CADASTRE-SE</a>
				<!--<a href="abrir-conta" class="suave-up btn botao-conta-include hidden-xs">ABRA SUA CONTA</a>
				<a href="abrir-conta-celular" class="btn botao-conta-include hidden-md">ABRA SUA CONTA</a>-->
			</div>
		
			<div class="col-md-3">
				<img src="images/mockup-novo.png" alt="App LTW Bank" class="w-100" />
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
</div>